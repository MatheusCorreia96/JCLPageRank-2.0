package principal;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;

import implementations.dm_kernel.user.JCL_FacadeImpl;
import interfaces.kernel.JCL_facade;

public class ParallelUpdate<S> extends Thread{
	

	JCL_facade jclLambari = JCL_FacadeImpl.getInstanceLambari();
	ConcurrentHashMap<String, String> localGraphNeighbors = (ConcurrentHashMap<String, String>) jclLambari.getValue("localGraphNeighbors").getCorrectResult();

	ConcurrentSkipListSet<Neighbors> keys;
//	Neighbors key;
	
	public ParallelUpdate(ConcurrentSkipListSet<Neighbors> keys){
		this.keys = keys;
	}
//	
//	public ParallelUpdate(Neighbors key){
//		this.key = key;
//	}
	
	public void run(){
		
	
		for(Neighbors key: keys){

			if(localGraphNeighbors.get(key.key) != null){
				String[] split = localGraphNeighbors.get(key.key).split(":");
			
				localGraphNeighbors.put(key.key, key.pagerank+":"+split[1]);		
			}
		}
		
	}
	

}

